package com.masai.books.BookManagement.service;


import org.springframework.stereotype.Service;

@Service
public class ReviewService {
}
